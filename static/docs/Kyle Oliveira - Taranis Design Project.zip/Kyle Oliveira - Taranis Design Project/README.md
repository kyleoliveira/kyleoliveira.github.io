# NERF N-Strike Elite ZS-4 Taranis Airship
## Model-based Systems Engineering
## Final Design Project

Cornell University�s Systems Engineering 5110 course, Model-based Systems Engineering, 
is an introduction to the practice of Systems Engineering based around the use of a 
number of industry-proven Systems Engineering design tools. Throughout the course, 
students are tasked with applying the tools presented in lecture toward a semester-long 
design project. This semester�s project was to design a toy for Hasbro, Inc. 
and the Request For Proposal (RFP) was delivered as follows:

```
Hasbro is a worldwide leader in children's and family leisure time products and services with a rich portfolio of brands and entertainment properties that provides some of the highest quality and most recognizable play and recreational experiences in the world. As a brand-driven, consumer-focused global company, Hasbro brings to market a range of toys, games and licensed products, from traditional to high-tech and digital, under such powerful brand names as TRANSFORMERS, MONOPOLY, LITTLEST PET SHOP, MY LITTLE PONY, PLAYSKOOL, TONKA, GI JOE, MR. POTATO HEAD, NERF, BABY ALIVE, STAR WARS, FURREAL FRIENDS, EZ BAKE OVEN, PLAY DOH, I-DOG and many others.

As a member of the DAVANNE LLC toy consulting company, you have been given the opportunity to pitch your own toy design to Hasbro. In order to remain competitive in today's market, initial market research suggests that Hasbro will be most interested in toys that involve some �working components� whether they�re mechanical, electrical, or both. Toy concepts that demonstrate both the most unique and the best thought-out designs will be given the highest consideration. 

The target shelf price for the toy should be no more than approximately $50, with toys under the $30 range preferred.  Your final design will be presented in two copies, one for Cornell and one for Hasbro Team to review. Some of the presentation content may be used to �sell� your product design to a perspective toy designer and/or consumer. However, the majority of the design presentation and the elements that Hasbro will be scrutinizing the most will be the design documentation that demonstrates the translation of customer needs into a final design, documentation justifying your design decisions and trade-offs, as well as details on the functional description, operation, implementation, and validation of your design.
```